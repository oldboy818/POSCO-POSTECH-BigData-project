# posco-streamlit

In Posco AI Edu 20th A2  
for BigData course presentation.  
"Baby Product promotion and recommend"
